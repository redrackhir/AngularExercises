export class User {
  uid: number;
  name: string;
  accessLevel: string;
  ppin: string;
}
